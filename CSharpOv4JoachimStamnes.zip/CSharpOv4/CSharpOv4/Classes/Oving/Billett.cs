﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpOv4.Classes.Oving
{
    public class Billett
    {
        public Billett(string tribunenavn, double pris)
        {

        }

    }
}
